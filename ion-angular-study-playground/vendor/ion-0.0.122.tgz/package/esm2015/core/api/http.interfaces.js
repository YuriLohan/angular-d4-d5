/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 * @template DataType
 */
export function BnService() { }
if (false) {
    /** @type {?|undefined} */
    BnService.prototype.list;
    /** @type {?|undefined} */
    BnService.prototype.insert;
    /** @type {?|undefined} */
    BnService.prototype.get;
}
/**
 * @record
 * @template DataType
 */
export function IResponse() { }
if (false) {
    /** @type {?|undefined} */
    IResponse.prototype.data;
    /** @type {?|undefined} */
    IResponse.prototype.dados;
    /** @type {?|undefined} */
    IResponse.prototype.total;
    /** @type {?|undefined} */
    IResponse.prototype.mensagem;
    /* Skipping unhandled member: [x: string]: SafeAny;*/
}
/**
 * @record
 */
export function IPayload() { }
if (false) {
    /** @type {?|undefined} */
    IPayload.prototype.filter;
    /* Skipping unhandled member: [x: string]: SafeAny;*/
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHR0cC5pbnRlcmZhY2VzLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGJyaXNhbmV0L2lvbi8iLCJzb3VyY2VzIjpbImNvcmUvYXBpL2h0dHAuaW50ZXJmYWNlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUlBLCtCQUlDOzs7SUFIQyx5QkFBK0Q7O0lBQy9ELDJCQUFvRDs7SUFDcEQsd0JBQXNEOzs7Ozs7QUFHeEQsK0JBTUM7OztJQUxDLHlCQUFrQjs7SUFDbEIsMEJBQW1COztJQUNuQiwwQkFBZTs7SUFDZiw2QkFBa0I7Ozs7OztBQUlwQiw4QkFHQzs7O0lBREMsMEJBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2FmZUFueSB9IGZyb20gJy4uLy4uL2xpYi91dGlscy9zYWZlLWFueSc7XG5pbXBvcnQgeyBTbWFydFBheWxvYWQgfSBmcm9tICcuLi9ibi10YWJsZS9ibi10YWJsZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQm5TZXJ2aWNlPERhdGFUeXBlPiB7XG4gIGxpc3Q/OiAoZmlsdGVycz86IElQYXlsb2FkKSA9PiBPYnNlcnZhYmxlPElSZXNwb25zZTxEYXRhVHlwZT4+O1xuICBpbnNlcnQ/OiAocGF5bG9hZDogSVBheWxvYWQpID0+IE9ic2VydmFibGU8U2FmZUFueT47XG4gIGdldD86IChpdGVtOiBudW1iZXIgfCBzdHJpbmcpID0+IE9ic2VydmFibGU8RGF0YVR5cGU+O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElSZXNwb25zZTxEYXRhVHlwZT4ge1xuICBkYXRhPzogRGF0YVR5cGVbXTtcbiAgZGFkb3M/OiBEYXRhVHlwZVtdO1xuICB0b3RhbD86IG51bWJlcjtcbiAgbWVuc2FnZW0/OiBzdHJpbmc7XG4gIFt4OiBzdHJpbmddOiBTYWZlQW55O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElQYXlsb2FkIGV4dGVuZHMgU21hcnRQYXlsb2FkIHtcbiAgW3g6IHN0cmluZ106IFNhZmVBbnk7XG4gIGZpbHRlcj86IFNhZmVBbnk7XG59XG4iXX0=