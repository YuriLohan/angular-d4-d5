/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { isEmpty } from './isEmpty';
/**
 * @template T
 * @param {?} value
 * @return {?}
 */
export function clearObject(value) {
    Object.keys(value).forEach((/**
     * @param {?} key
     * @return {?}
     */
    (key) => {
        if (isNestedObj(value[key])) {
            clearObject(value[key]);
        }
        if (shouldDelete(value[key])) {
            delete value[key];
        }
    }));
    return value;
}
/**
 * @param {?} value
 * @return {?}
 */
function isNestedObj(value) {
    return value && !Array.isArray(value) && typeof value === 'object';
}
/**
 * @param {?} value
 * @return {?}
 */
function shouldDelete(value) {
    return ([null, undefined, ''].includes(value) ||
        Number.isNaN(value) ||
        (Array.isArray(value) && isEmpty(value)));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xlYXJPYmplY3QuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AYnJpc2FuZXQvaW9uLyIsInNvdXJjZXMiOlsiY29yZS91dGlscy9jbGVhck9iamVjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQ0EsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLFdBQVcsQ0FBQzs7Ozs7O0FBRXBDLE1BQU0sVUFBVSxXQUFXLENBQWMsS0FBYztJQUNyRCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU87Ozs7SUFBQyxDQUFDLEdBQUcsRUFBRSxFQUFFO1FBQ2pDLElBQUksV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQzNCLFdBQVcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUN6QjtRQUVELElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1lBQzVCLE9BQU8sS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ25CO0lBQ0gsQ0FBQyxFQUFDLENBQUM7SUFDSCxPQUFPLEtBQUssQ0FBQztBQUNmLENBQUM7Ozs7O0FBRUQsU0FBUyxXQUFXLENBQUMsS0FBYztJQUNqQyxPQUFPLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxDQUFDO0FBQ3JFLENBQUM7Ozs7O0FBRUQsU0FBUyxZQUFZLENBQUMsS0FBYztJQUNsQyxPQUFPLENBQ0wsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7UUFDckMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDbkIsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUN6QyxDQUFDO0FBQ0osQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNhZmVBbnkgfSBmcm9tICcuLi8uLi9saWIvdXRpbHMvc2FmZS1hbnknO1xuaW1wb3J0IHsgaXNFbXB0eSB9IGZyb20gJy4vaXNFbXB0eSc7XG5cbmV4cG9ydCBmdW5jdGlvbiBjbGVhck9iamVjdDxUID0gU2FmZUFueT4odmFsdWU6IFNhZmVBbnkpOiBUIHtcbiAgT2JqZWN0LmtleXModmFsdWUpLmZvckVhY2goKGtleSkgPT4ge1xuICAgIGlmIChpc05lc3RlZE9iaih2YWx1ZVtrZXldKSkge1xuICAgICAgY2xlYXJPYmplY3QodmFsdWVba2V5XSk7XG4gICAgfVxuXG4gICAgaWYgKHNob3VsZERlbGV0ZSh2YWx1ZVtrZXldKSkge1xuICAgICAgZGVsZXRlIHZhbHVlW2tleV07XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIHZhbHVlO1xufVxuXG5mdW5jdGlvbiBpc05lc3RlZE9iaih2YWx1ZTogU2FmZUFueSk6IGJvb2xlYW4ge1xuICByZXR1cm4gdmFsdWUgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCc7XG59XG5cbmZ1bmN0aW9uIHNob3VsZERlbGV0ZSh2YWx1ZTogU2FmZUFueSk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIFtudWxsLCB1bmRlZmluZWQsICcnXS5pbmNsdWRlcyh2YWx1ZSkgfHxcbiAgICBOdW1iZXIuaXNOYU4odmFsdWUpIHx8XG4gICAgKEFycmF5LmlzQXJyYXkodmFsdWUpICYmIGlzRW1wdHkodmFsdWUpKVxuICApO1xufVxuIl19