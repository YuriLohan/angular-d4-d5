/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function PipeStrategy() { }
if (false) {
    /**
     * @param {?} value
     * @param {?=} format
     * @return {?}
     */
    PipeStrategy.prototype.transform = function (value, format) { };
}
export class PipeApplicator {
    /**
     * @param {?} strategy
     */
    constructor(strategy) {
        this.strategy = strategy;
    }
    /**
     * @param {?} value
     * @param {?=} format
     * @return {?}
     */
    apply(value, format) {
        return this.strategy.transform(value, format);
    }
}
if (false) {
    /**
     * @type {?}
     * @private
     */
    PipeApplicator.prototype.strategy;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGlwZS1zdHJhdGVneS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BicmlzYW5ldC9pb24vIiwic291cmNlcyI6WyJjb3JlL3BpcGVzL3BpcGUtc3RyYXRlZ3kudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLGtDQUVDOzs7Ozs7O0lBREMsZ0VBQTJEOztBQUc3RCxNQUFNLE9BQU8sY0FBYzs7OztJQUd6QixZQUFZLFFBQXNCO1FBQ2hDLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0lBQzNCLENBQUM7Ozs7OztJQUVELEtBQUssQ0FBQyxLQUFzQixFQUFFLE1BQWU7UUFDM0MsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDaEQsQ0FBQztDQUNGOzs7Ozs7SUFUQyxrQ0FBK0IiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIFBpcGVTdHJhdGVneSB7XG4gIHRyYW5zZm9ybSh2YWx1ZTogc3RyaW5nIHwgbnVtYmVyLCBmb3JtYXQ/OiBzdHJpbmcpOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjbGFzcyBQaXBlQXBwbGljYXRvciB7XG4gIHByaXZhdGUgc3RyYXRlZ3k6IFBpcGVTdHJhdGVneTtcblxuICBjb25zdHJ1Y3RvcihzdHJhdGVneTogUGlwZVN0cmF0ZWd5KSB7XG4gICAgdGhpcy5zdHJhdGVneSA9IHN0cmF0ZWd5O1xuICB9XG5cbiAgYXBwbHkodmFsdWU6IHN0cmluZyB8IG51bWJlciwgZm9ybWF0Pzogc3RyaW5nKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5zdHJhdGVneS50cmFuc2Zvcm0odmFsdWUsIGZvcm1hdCk7XG4gIH1cbn1cbiJdfQ==