/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { CurrencyPipe } from '@angular/common';
export class CurrencyPipeStrategy {
    /**
     * @param {?} value
     * @return {?}
     */
    transform(value) {
        /** @type {?} */
        const locale = 'en-US';
        /** @type {?} */
        const currencyPipe = new CurrencyPipe(locale);
        return currencyPipe.transform(value, 'BRL', 'symbol', '1.2-2');
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VycmVuY3kucGlwZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BicmlzYW5ldC9pb24vIiwic291cmNlcyI6WyJjb3JlL3BpcGVzL2N1cnJlbmN5LnBpcGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUcvQyxNQUFNLE9BQU8sb0JBQW9COzs7OztJQUMvQixTQUFTLENBQUMsS0FBYTs7Y0FDZixNQUFNLEdBQUcsT0FBTzs7Y0FDaEIsWUFBWSxHQUFHLElBQUksWUFBWSxDQUFDLE1BQU0sQ0FBQztRQUM3QyxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDakUsQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ3VycmVuY3lQaXBlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IFBpcGVTdHJhdGVneSB9IGZyb20gJy4vcGlwZS1zdHJhdGVneSc7XG5cbmV4cG9ydCBjbGFzcyBDdXJyZW5jeVBpcGVTdHJhdGVneSBpbXBsZW1lbnRzIFBpcGVTdHJhdGVneSB7XG4gIHRyYW5zZm9ybSh2YWx1ZTogbnVtYmVyKTogc3RyaW5nIHtcbiAgICBjb25zdCBsb2NhbGUgPSAnZW4tVVMnO1xuICAgIGNvbnN0IGN1cnJlbmN5UGlwZSA9IG5ldyBDdXJyZW5jeVBpcGUobG9jYWxlKTtcbiAgICByZXR1cm4gY3VycmVuY3lQaXBlLnRyYW5zZm9ybSh2YWx1ZSwgJ0JSTCcsICdzeW1ib2wnLCAnMS4yLTInKTtcbiAgfVxufVxuIl19