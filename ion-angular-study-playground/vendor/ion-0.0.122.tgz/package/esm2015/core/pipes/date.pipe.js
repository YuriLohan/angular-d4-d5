/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { DatePipe } from '@angular/common';
export class DatePipeStrategy {
    /**
     * @param {?} value
     * @param {?=} format
     * @return {?}
     */
    transform(value, format) {
        /** @type {?} */
        const locale = 'pt-BR';
        /** @type {?} */
        const datePipe = new DatePipe(locale);
        return datePipe.transform(value, format);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZS5waXBlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGJyaXNhbmV0L2lvbi8iLCJzb3VyY2VzIjpbImNvcmUvcGlwZXMvZGF0ZS5waXBlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFHM0MsTUFBTSxPQUFPLGdCQUFnQjs7Ozs7O0lBQzNCLFNBQVMsQ0FBQyxLQUFhLEVBQUUsTUFBZTs7Y0FDaEMsTUFBTSxHQUFHLE9BQU87O2NBQ2hCLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxNQUFNLENBQUM7UUFDckMsT0FBTyxRQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztJQUMzQyxDQUFDO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEYXRlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBQaXBlU3RyYXRlZ3kgfSBmcm9tICcuL3BpcGUtc3RyYXRlZ3knO1xuXG5leHBvcnQgY2xhc3MgRGF0ZVBpcGVTdHJhdGVneSBpbXBsZW1lbnRzIFBpcGVTdHJhdGVneSB7XG4gIHRyYW5zZm9ybSh2YWx1ZTogc3RyaW5nLCBmb3JtYXQ/OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IGxvY2FsZSA9ICdwdC1CUic7XG4gICAgY29uc3QgZGF0ZVBpcGUgPSBuZXcgRGF0ZVBpcGUobG9jYWxlKTtcbiAgICByZXR1cm4gZGF0ZVBpcGUudHJhbnNmb3JtKHZhbHVlLCBmb3JtYXQpO1xuICB9XG59XG4iXX0=