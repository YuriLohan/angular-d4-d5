/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { forkJoin, of } from 'rxjs';
import { finalize, take } from 'rxjs/operators';
import { LIST_OF_PAGE_OPTIONS } from '../../lib/pagination/pagination.component';
import { EventTable } from '../../lib/table/utilsTable';
import { clearObject } from '../utils/clearObject';
/**
 * @record
 */
export function SmartPayload() { }
if (false) {
    /** @type {?|undefined} */
    SmartPayload.prototype.offset;
    /** @type {?|undefined} */
    SmartPayload.prototype.total;
    /** @type {?|undefined} */
    SmartPayload.prototype.limit;
    /** @type {?|undefined} */
    SmartPayload.prototype.order;
    /** @type {?|undefined} */
    SmartPayload.prototype.sort;
}
/**
 * @record
 * @template DataType
 */
export function IBnTable() { }
if (false) {
    /** @type {?} */
    IBnTable.prototype.service;
    /** @type {?} */
    IBnTable.prototype.tableConfig;
    /** @type {?|undefined} */
    IBnTable.prototype.formatData;
}
/**
 * @template DataType
 */
export default class BnTable {
    /**
     * @param {?} config
     */
    constructor(config) {
        this.configTable = {
            data: [],
            columns: [],
            actions: [],
            pagination: {
                total: 0,
                itemsPerPage: LIST_OF_PAGE_OPTIONS[0],
                pageSizeOptions: LIST_OF_PAGE_OPTIONS,
            },
            loading: false,
        };
        this.payload = {
            total: true,
            offset: this.configTable.pagination.offset || 0,
            limit: this.configTable.pagination.itemsPerPage,
        };
        this.firstLoad = true;
        this.service = config.service;
        // set configs
        this.configTable.columns = config.tableConfig.columns;
        this.configTable.actions = config.tableConfig.actions;
        this.formatData = config.formatData;
        this.onInit();
    }
    /**
     * @template T
     * @param {?} filter
     * @return {?}
     */
    filter(filter) {
        this.payload = Object.assign({}, this.payload, filter);
        clearObject(this.payload);
        this.resetTablePagination();
        this.smartData();
    }
    /**
     * @return {?}
     */
    smartData() {
        this.configTable.loading = true;
        if (this.firstLoad) {
            /** @type {?} */
            const firstOrderedColumn = this.configTable.columns.filter((/**
             * @param {?} column
             * @return {?}
             */
            (column) => column.desc !== undefined))[0];
            if (firstOrderedColumn) {
                this.handleSort({
                    column: firstOrderedColumn.key,
                    desc: firstOrderedColumn.desc,
                });
            }
            this.firstLoad = false;
        }
        /** @type {?} */
        const totalRequest$ = this.payload.total
            ? this.service.list(this.payload).pipe(take(1))
            : of(null);
        /** @type {?} */
        const dataRequest$ = this.service
            .list(Object.assign({}, this.payload, { total: false }))
            .pipe(take(1));
        forkJoin([totalRequest$, dataRequest$])
            .pipe(finalize((/**
         * @return {?}
         */
        () => (this.configTable.loading = false))))
            .subscribe((/**
         * @param {?} response
         * @return {?}
         */
        (response) => {
            const [totalResponse, dataResponse] = response;
            if (totalResponse && totalResponse.total !== null) {
                this.configTable.pagination = Object.assign({}, this.configTable.pagination, { total: totalResponse.total || 0 });
            }
            this.configTable.data = dataResponse.dados || dataResponse.data || [];
            if (this.formatData) {
                this.configTable.data = this.formatData(this.configTable.data);
            }
        }), (/**
         * @return {?}
         */
        () => {
            // TODO: add notification service
            // const msg: string = error.msg || error.error.msg;
            // this.notify.error('Erro', msg);
        }));
    }
    /**
     * @param {?} event
     * @return {?}
     */
    events(event) {
        /** @type {?} */
        const eventHandlers = {
            [EventTable.CHANGE_PAGE]: (/**
             * @return {?}
             */
            () => this.handlePageChange(event.change_page)),
            [EventTable.SORT]: (/**
             * @return {?}
             */
            () => event.order && this.handleSort(event.order)),
            [EventTable.REFRESH_FILTER]: (/**
             * @return {?}
             */
            () => this.filter(event.data)),
        };
        /** @type {?} */
        const handler = eventHandlers[event.event];
        if (handler) {
            handler();
        }
        if (event.event !== EventTable.REFRESH_FILTER) {
            this.smartData();
        }
    }
    /**
     * @param {?} changePage
     * @return {?}
     */
    handlePageChange(changePage) {
        this.payload.limit = changePage.itemsPerPage;
        this.payload.offset = changePage.offset;
        this.configTable.pagination.page = changePage.actual;
    }
    /**
     * @param {?} order
     * @return {?}
     */
    handleSort(order) {
        this.payload.order = order.column;
        this.payload.sort = order.desc ? 'desc' : 'asc';
        this.resetTablePagination();
    }
    /**
     * @private
     * @return {?}
     */
    resetTablePagination() {
        this.configTable.pagination.offset = 0;
        this.configTable.pagination.total = 0;
        this.configTable.pagination.page = 1;
        this.payload.offset = 0;
    }
    /**
     * @private
     * @return {?}
     */
    onInit() {
        this.smartData();
    }
}
if (false) {
    /** @type {?} */
    BnTable.prototype.configTable;
    /** @type {?} */
    BnTable.prototype.payload;
    /**
     * @type {?}
     * @private
     */
    BnTable.prototype.service;
    /**
     * @type {?}
     * @private
     */
    BnTable.prototype.formatData;
    /**
     * @type {?}
     * @private
     */
    BnTable.prototype.firstLoad;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm4tdGFibGUuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AYnJpc2FuZXQvaW9uLyIsInNvdXJjZXMiOlsiY29yZS9ibi10YWJsZS9ibi10YWJsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDcEMsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNoRCxPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSwyQ0FBMkMsQ0FBQztBQUNqRixPQUFPLEVBQWUsVUFBVSxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFRckUsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHNCQUFzQixDQUFDOzs7O0FBRW5ELGtDQU1DOzs7SUFMQyw4QkFBZ0I7O0lBQ2hCLDZCQUFnQjs7SUFDaEIsNkJBQWU7O0lBQ2YsNkJBQWU7O0lBQ2YsNEJBQWM7Ozs7OztBQUdoQiw4QkFJQzs7O0lBSEMsMkJBQTZCOztJQUM3QiwrQkFBZ0U7O0lBQ2hFLDhCQUE4Qzs7Ozs7QUFHaEQsTUFBTSxDQUFDLE9BQU8sT0FBTyxPQUFPOzs7O0lBdUIxQixZQUFZLE1BQTBCO1FBdEIvQixnQkFBVyxHQUErQjtZQUMvQyxJQUFJLEVBQUUsRUFBRTtZQUNSLE9BQU8sRUFBRSxFQUFFO1lBQ1gsT0FBTyxFQUFFLEVBQUU7WUFDWCxVQUFVLEVBQUU7Z0JBQ1YsS0FBSyxFQUFFLENBQUM7Z0JBQ1IsWUFBWSxFQUFFLG9CQUFvQixDQUFDLENBQUMsQ0FBQztnQkFDckMsZUFBZSxFQUFFLG9CQUFvQjthQUN0QztZQUNELE9BQU8sRUFBRSxLQUFLO1NBQ2YsQ0FBQztRQUVLLFlBQU8sR0FBYTtZQUN6QixLQUFLLEVBQUUsSUFBSTtZQUNYLE1BQU0sRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FBQztZQUMvQyxLQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsWUFBWTtTQUNoRCxDQUFDO1FBSU0sY0FBUyxHQUFHLElBQUksQ0FBQztRQUd2QixJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFFOUIsY0FBYztRQUNkLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDO1FBQ3RELElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDO1FBRXRELElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQztRQUNwQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDaEIsQ0FBQzs7Ozs7O0lBRUQsTUFBTSxDQUFlLE1BQVM7UUFDNUIsSUFBSSxDQUFDLE9BQU8scUJBQ1AsSUFBSSxDQUFDLE9BQU8sRUFDWixNQUFNLENBQ1YsQ0FBQztRQUNGLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ25CLENBQUM7Ozs7SUFFRCxTQUFTO1FBQ1AsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRWhDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTs7a0JBQ1osa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTTs7OztZQUN4RCxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxTQUFTLEVBQ3RDLENBQUMsQ0FBQyxDQUFDO1lBRUosSUFBSSxrQkFBa0IsRUFBRTtnQkFDdEIsSUFBSSxDQUFDLFVBQVUsQ0FBQztvQkFDZCxNQUFNLEVBQUUsa0JBQWtCLENBQUMsR0FBRztvQkFDOUIsSUFBSSxFQUFFLGtCQUFrQixDQUFDLElBQUk7aUJBQzlCLENBQUMsQ0FBQzthQUNKO1lBRUQsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7U0FDeEI7O2NBRUssYUFBYSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSztZQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7O2NBRU4sWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPO2FBQzlCLElBQUksbUJBQU0sSUFBSSxDQUFDLE9BQU8sSUFBRSxLQUFLLEVBQUUsS0FBSyxJQUFHO2FBQ3ZDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEIsUUFBUSxDQUFDLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQyxDQUFDO2FBQ3BDLElBQUksQ0FBQyxRQUFROzs7UUFBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxFQUFDLENBQUM7YUFDeEQsU0FBUzs7OztRQUNSLENBQUMsUUFBUSxFQUFFLEVBQUU7a0JBQ0wsQ0FBQyxhQUFhLEVBQUUsWUFBWSxDQUFDLEdBRy9CLFFBQVE7WUFFWixJQUFJLGFBQWEsSUFBSSxhQUFhLENBQUMsS0FBSyxLQUFLLElBQUksRUFBRTtnQkFDakQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLHFCQUN0QixJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsSUFDOUIsS0FBSyxFQUFFLGFBQWEsQ0FBQyxLQUFLLElBQUksQ0FBQyxHQUNoQyxDQUFDO2FBQ0g7WUFFRCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksR0FBRyxZQUFZLENBQUMsS0FBSyxJQUFJLFlBQVksQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDO1lBRXRFLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQ2hFO1FBQ0gsQ0FBQzs7O1FBQ0QsR0FBRyxFQUFFO1lBQ0gsaUNBQWlDO1lBQ2pDLG9EQUFvRDtZQUNwRCxrQ0FBa0M7UUFDcEMsQ0FBQyxFQUNGLENBQUM7SUFDTixDQUFDOzs7OztJQUVELE1BQU0sQ0FBQyxLQUFzQjs7Y0FDckIsYUFBYSxHQUFHO1lBQ3BCLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQzs7O1lBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQTtZQUN4RSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7OztZQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUE7WUFDcEUsQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDOzs7WUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtTQUMzRDs7Y0FFSyxPQUFPLEdBQUcsYUFBYSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDMUMsSUFBSSxPQUFPLEVBQUU7WUFDWCxPQUFPLEVBQUUsQ0FBQztTQUNYO1FBRUQsSUFBSSxLQUFLLENBQUMsS0FBSyxLQUFLLFVBQVUsQ0FBQyxjQUFjLEVBQUU7WUFDN0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1NBQ2xCO0lBQ0gsQ0FBQzs7Ozs7SUFFRCxnQkFBZ0IsQ0FBQyxVQUFxQjtRQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsWUFBWSxDQUFDO1FBQzdDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFDeEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUM7SUFDdkQsQ0FBQzs7Ozs7SUFFRCxVQUFVLENBQUMsS0FBc0I7UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUNsQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUVoRCxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztJQUM5QixDQUFDOzs7OztJQUVPLG9CQUFvQjtRQUMxQixJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUVyQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDMUIsQ0FBQzs7Ozs7SUFFTyxNQUFNO1FBQ1osSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ25CLENBQUM7Q0FDRjs7O0lBNUlDLDhCQVVFOztJQUVGLDBCQUlFOzs7OztJQUVGLDBCQUFxQzs7Ozs7SUFDckMsNkJBQXFEOzs7OztJQUNyRCw0QkFBeUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBmb3JrSm9pbiwgb2YgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IGZpbmFsaXplLCB0YWtlIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xuaW1wb3J0IHsgTElTVF9PRl9QQUdFX09QVElPTlMgfSBmcm9tICcuLi8uLi9saWIvcGFnaW5hdGlvbi9wYWdpbmF0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb25maWdUYWJsZSwgRXZlbnRUYWJsZSB9IGZyb20gJy4uLy4uL2xpYi90YWJsZS91dGlsc1RhYmxlJztcbmltcG9ydCB7XG4gIENvbmZpZ1NtYXJ0VGFibGUsXG4gIE9yZGVyVGFibGVFdmVudCxcbiAgUGFnZUV2ZW50LFxuICBTbWFydFRhYmxlRXZlbnQsXG59IGZyb20gJy4uLy4uL3B1YmxpYy1hcGknO1xuaW1wb3J0IHsgQm5TZXJ2aWNlLCBJUGF5bG9hZCwgSVJlc3BvbnNlIH0gZnJvbSAnLi4vYXBpL2h0dHAuaW50ZXJmYWNlcyc7XG5pbXBvcnQgeyBjbGVhck9iamVjdCB9IGZyb20gJy4uL3V0aWxzL2NsZWFyT2JqZWN0JztcblxuZXhwb3J0IGludGVyZmFjZSBTbWFydFBheWxvYWQge1xuICBvZmZzZXQ/OiBudW1iZXI7XG4gIHRvdGFsPzogYm9vbGVhbjtcbiAgbGltaXQ/OiBudW1iZXI7XG4gIG9yZGVyPzogc3RyaW5nO1xuICBzb3J0Pzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElCblRhYmxlPERhdGFUeXBlPiB7XG4gIHNlcnZpY2U6IEJuU2VydmljZTxEYXRhVHlwZT47XG4gIHRhYmxlQ29uZmlnOiBQaWNrPENvbmZpZ1RhYmxlPERhdGFUeXBlPiwgJ2NvbHVtbnMnIHwgJ2FjdGlvbnMnPjtcbiAgZm9ybWF0RGF0YT86IChkYXRhOiBEYXRhVHlwZVtdKSA9PiBEYXRhVHlwZVtdO1xufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBCblRhYmxlPERhdGFUeXBlPiB7XG4gIHB1YmxpYyBjb25maWdUYWJsZTogQ29uZmlnU21hcnRUYWJsZTxEYXRhVHlwZT4gPSB7XG4gICAgZGF0YTogW10sXG4gICAgY29sdW1uczogW10sXG4gICAgYWN0aW9uczogW10sXG4gICAgcGFnaW5hdGlvbjoge1xuICAgICAgdG90YWw6IDAsXG4gICAgICBpdGVtc1BlclBhZ2U6IExJU1RfT0ZfUEFHRV9PUFRJT05TWzBdLFxuICAgICAgcGFnZVNpemVPcHRpb25zOiBMSVNUX09GX1BBR0VfT1BUSU9OUyxcbiAgICB9LFxuICAgIGxvYWRpbmc6IGZhbHNlLFxuICB9O1xuXG4gIHB1YmxpYyBwYXlsb2FkOiBJUGF5bG9hZCA9IHtcbiAgICB0b3RhbDogdHJ1ZSxcbiAgICBvZmZzZXQ6IHRoaXMuY29uZmlnVGFibGUucGFnaW5hdGlvbi5vZmZzZXQgfHwgMCxcbiAgICBsaW1pdDogdGhpcy5jb25maWdUYWJsZS5wYWdpbmF0aW9uLml0ZW1zUGVyUGFnZSxcbiAgfTtcblxuICBwcml2YXRlIHNlcnZpY2U6IEJuU2VydmljZTxEYXRhVHlwZT47XG4gIHByaXZhdGUgZm9ybWF0RGF0YTogKGRhdGE6IERhdGFUeXBlW10pID0+IERhdGFUeXBlW107XG4gIHByaXZhdGUgZmlyc3RMb2FkID0gdHJ1ZTtcblxuICBjb25zdHJ1Y3Rvcihjb25maWc6IElCblRhYmxlPERhdGFUeXBlPikge1xuICAgIHRoaXMuc2VydmljZSA9IGNvbmZpZy5zZXJ2aWNlO1xuXG4gICAgLy8gc2V0IGNvbmZpZ3NcbiAgICB0aGlzLmNvbmZpZ1RhYmxlLmNvbHVtbnMgPSBjb25maWcudGFibGVDb25maWcuY29sdW1ucztcbiAgICB0aGlzLmNvbmZpZ1RhYmxlLmFjdGlvbnMgPSBjb25maWcudGFibGVDb25maWcuYWN0aW9ucztcblxuICAgIHRoaXMuZm9ybWF0RGF0YSA9IGNvbmZpZy5mb3JtYXREYXRhO1xuICAgIHRoaXMub25Jbml0KCk7XG4gIH1cblxuICBmaWx0ZXI8VCA9IERhdGFUeXBlPihmaWx0ZXI6IFQpOiB2b2lkIHtcbiAgICB0aGlzLnBheWxvYWQgPSB7XG4gICAgICAuLi50aGlzLnBheWxvYWQsXG4gICAgICAuLi5maWx0ZXIsXG4gICAgfTtcbiAgICBjbGVhck9iamVjdCh0aGlzLnBheWxvYWQpO1xuICAgIHRoaXMucmVzZXRUYWJsZVBhZ2luYXRpb24oKTtcbiAgICB0aGlzLnNtYXJ0RGF0YSgpO1xuICB9XG5cbiAgc21hcnREYXRhKCk6IHZvaWQge1xuICAgIHRoaXMuY29uZmlnVGFibGUubG9hZGluZyA9IHRydWU7XG5cbiAgICBpZiAodGhpcy5maXJzdExvYWQpIHtcbiAgICAgIGNvbnN0IGZpcnN0T3JkZXJlZENvbHVtbiA9IHRoaXMuY29uZmlnVGFibGUuY29sdW1ucy5maWx0ZXIoXG4gICAgICAgIChjb2x1bW4pID0+IGNvbHVtbi5kZXNjICE9PSB1bmRlZmluZWRcbiAgICAgIClbMF07XG5cbiAgICAgIGlmIChmaXJzdE9yZGVyZWRDb2x1bW4pIHtcbiAgICAgICAgdGhpcy5oYW5kbGVTb3J0KHtcbiAgICAgICAgICBjb2x1bW46IGZpcnN0T3JkZXJlZENvbHVtbi5rZXksXG4gICAgICAgICAgZGVzYzogZmlyc3RPcmRlcmVkQ29sdW1uLmRlc2MsXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmZpcnN0TG9hZCA9IGZhbHNlO1xuICAgIH1cblxuICAgIGNvbnN0IHRvdGFsUmVxdWVzdCQgPSB0aGlzLnBheWxvYWQudG90YWxcbiAgICAgID8gdGhpcy5zZXJ2aWNlLmxpc3QodGhpcy5wYXlsb2FkKS5waXBlKHRha2UoMSkpXG4gICAgICA6IG9mKG51bGwpO1xuXG4gICAgY29uc3QgZGF0YVJlcXVlc3QkID0gdGhpcy5zZXJ2aWNlXG4gICAgICAubGlzdCh7IC4uLnRoaXMucGF5bG9hZCwgdG90YWw6IGZhbHNlIH0pXG4gICAgICAucGlwZSh0YWtlKDEpKTtcblxuICAgIGZvcmtKb2luKFt0b3RhbFJlcXVlc3QkLCBkYXRhUmVxdWVzdCRdKVxuICAgICAgLnBpcGUoZmluYWxpemUoKCkgPT4gKHRoaXMuY29uZmlnVGFibGUubG9hZGluZyA9IGZhbHNlKSkpXG4gICAgICAuc3Vic2NyaWJlKFxuICAgICAgICAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICBjb25zdCBbdG90YWxSZXNwb25zZSwgZGF0YVJlc3BvbnNlXTogW1xuICAgICAgICAgICAgSVJlc3BvbnNlPERhdGFUeXBlPixcbiAgICAgICAgICAgIElSZXNwb25zZTxEYXRhVHlwZT5cbiAgICAgICAgICBdID0gcmVzcG9uc2U7XG5cbiAgICAgICAgICBpZiAodG90YWxSZXNwb25zZSAmJiB0b3RhbFJlc3BvbnNlLnRvdGFsICE9PSBudWxsKSB7XG4gICAgICAgICAgICB0aGlzLmNvbmZpZ1RhYmxlLnBhZ2luYXRpb24gPSB7XG4gICAgICAgICAgICAgIC4uLnRoaXMuY29uZmlnVGFibGUucGFnaW5hdGlvbixcbiAgICAgICAgICAgICAgdG90YWw6IHRvdGFsUmVzcG9uc2UudG90YWwgfHwgMCxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdGhpcy5jb25maWdUYWJsZS5kYXRhID0gZGF0YVJlc3BvbnNlLmRhZG9zIHx8IGRhdGFSZXNwb25zZS5kYXRhIHx8IFtdO1xuXG4gICAgICAgICAgaWYgKHRoaXMuZm9ybWF0RGF0YSkge1xuICAgICAgICAgICAgdGhpcy5jb25maWdUYWJsZS5kYXRhID0gdGhpcy5mb3JtYXREYXRhKHRoaXMuY29uZmlnVGFibGUuZGF0YSk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgLy8gVE9ETzogYWRkIG5vdGlmaWNhdGlvbiBzZXJ2aWNlXG4gICAgICAgICAgLy8gY29uc3QgbXNnOiBzdHJpbmcgPSBlcnJvci5tc2cgfHwgZXJyb3IuZXJyb3IubXNnO1xuICAgICAgICAgIC8vIHRoaXMubm90aWZ5LmVycm9yKCdFcnJvJywgbXNnKTtcbiAgICAgICAgfVxuICAgICAgKTtcbiAgfVxuXG4gIGV2ZW50cyhldmVudDogU21hcnRUYWJsZUV2ZW50KTogdm9pZCB7XG4gICAgY29uc3QgZXZlbnRIYW5kbGVycyA9IHtcbiAgICAgIFtFdmVudFRhYmxlLkNIQU5HRV9QQUdFXTogKCkgPT4gdGhpcy5oYW5kbGVQYWdlQ2hhbmdlKGV2ZW50LmNoYW5nZV9wYWdlKSxcbiAgICAgIFtFdmVudFRhYmxlLlNPUlRdOiAoKSA9PiBldmVudC5vcmRlciAmJiB0aGlzLmhhbmRsZVNvcnQoZXZlbnQub3JkZXIpLFxuICAgICAgW0V2ZW50VGFibGUuUkVGUkVTSF9GSUxURVJdOiAoKSA9PiB0aGlzLmZpbHRlcihldmVudC5kYXRhKSxcbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlciA9IGV2ZW50SGFuZGxlcnNbZXZlbnQuZXZlbnRdO1xuICAgIGlmIChoYW5kbGVyKSB7XG4gICAgICBoYW5kbGVyKCk7XG4gICAgfVxuXG4gICAgaWYgKGV2ZW50LmV2ZW50ICE9PSBFdmVudFRhYmxlLlJFRlJFU0hfRklMVEVSKSB7XG4gICAgICB0aGlzLnNtYXJ0RGF0YSgpO1xuICAgIH1cbiAgfVxuXG4gIGhhbmRsZVBhZ2VDaGFuZ2UoY2hhbmdlUGFnZTogUGFnZUV2ZW50KTogdm9pZCB7XG4gICAgdGhpcy5wYXlsb2FkLmxpbWl0ID0gY2hhbmdlUGFnZS5pdGVtc1BlclBhZ2U7XG4gICAgdGhpcy5wYXlsb2FkLm9mZnNldCA9IGNoYW5nZVBhZ2Uub2Zmc2V0O1xuICAgIHRoaXMuY29uZmlnVGFibGUucGFnaW5hdGlvbi5wYWdlID0gY2hhbmdlUGFnZS5hY3R1YWw7XG4gIH1cblxuICBoYW5kbGVTb3J0KG9yZGVyOiBPcmRlclRhYmxlRXZlbnQpOiB2b2lkIHtcbiAgICB0aGlzLnBheWxvYWQub3JkZXIgPSBvcmRlci5jb2x1bW47XG4gICAgdGhpcy5wYXlsb2FkLnNvcnQgPSBvcmRlci5kZXNjID8gJ2Rlc2MnIDogJ2FzYyc7XG5cbiAgICB0aGlzLnJlc2V0VGFibGVQYWdpbmF0aW9uKCk7XG4gIH1cblxuICBwcml2YXRlIHJlc2V0VGFibGVQYWdpbmF0aW9uKCk6IHZvaWQge1xuICAgIHRoaXMuY29uZmlnVGFibGUucGFnaW5hdGlvbi5vZmZzZXQgPSAwO1xuICAgIHRoaXMuY29uZmlnVGFibGUucGFnaW5hdGlvbi50b3RhbCA9IDA7XG4gICAgdGhpcy5jb25maWdUYWJsZS5wYWdpbmF0aW9uLnBhZ2UgPSAxO1xuXG4gICAgdGhpcy5wYXlsb2FkLm9mZnNldCA9IDA7XG4gIH1cblxuICBwcml2YXRlIG9uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnNtYXJ0RGF0YSgpO1xuICB9XG59XG4iXX0=