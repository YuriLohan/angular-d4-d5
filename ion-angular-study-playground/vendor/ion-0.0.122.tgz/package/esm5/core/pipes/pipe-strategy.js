/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
export function PipeStrategy() { }
if (false) {
    /**
     * @param {?} value
     * @param {?=} format
     * @return {?}
     */
    PipeStrategy.prototype.transform = function (value, format) { };
}
var PipeApplicator = /** @class */ (function () {
    function PipeApplicator(strategy) {
        this.strategy = strategy;
    }
    /**
     * @param {?} value
     * @param {?=} format
     * @return {?}
     */
    PipeApplicator.prototype.apply = /**
     * @param {?} value
     * @param {?=} format
     * @return {?}
     */
    function (value, format) {
        return this.strategy.transform(value, format);
    };
    return PipeApplicator;
}());
export { PipeApplicator };
if (false) {
    /**
     * @type {?}
     * @private
     */
    PipeApplicator.prototype.strategy;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGlwZS1zdHJhdGVneS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BicmlzYW5ldC9pb24vIiwic291cmNlcyI6WyJjb3JlL3BpcGVzL3BpcGUtc3RyYXRlZ3kudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLGtDQUVDOzs7Ozs7O0lBREMsZ0VBQTJEOztBQUc3RDtJQUdFLHdCQUFZLFFBQXNCO1FBQ2hDLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0lBQzNCLENBQUM7Ozs7OztJQUVELDhCQUFLOzs7OztJQUFMLFVBQU0sS0FBc0IsRUFBRSxNQUFlO1FBQzNDLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFDSCxxQkFBQztBQUFELENBQUMsQUFWRCxJQVVDOzs7Ozs7O0lBVEMsa0NBQStCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGludGVyZmFjZSBQaXBlU3RyYXRlZ3kge1xuICB0cmFuc2Zvcm0odmFsdWU6IHN0cmluZyB8IG51bWJlciwgZm9ybWF0Pzogc3RyaW5nKTogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgUGlwZUFwcGxpY2F0b3Ige1xuICBwcml2YXRlIHN0cmF0ZWd5OiBQaXBlU3RyYXRlZ3k7XG5cbiAgY29uc3RydWN0b3Ioc3RyYXRlZ3k6IFBpcGVTdHJhdGVneSkge1xuICAgIHRoaXMuc3RyYXRlZ3kgPSBzdHJhdGVneTtcbiAgfVxuXG4gIGFwcGx5KHZhbHVlOiBzdHJpbmcgfCBudW1iZXIsIGZvcm1hdD86IHN0cmluZyk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuc3RyYXRlZ3kudHJhbnNmb3JtKHZhbHVlLCBmb3JtYXQpO1xuICB9XG59XG4iXX0=