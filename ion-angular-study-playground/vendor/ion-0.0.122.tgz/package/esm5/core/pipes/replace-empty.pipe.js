/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { ReplaceEmptyPipe } from '../../lib/utils/pipes/replace-empty';
var ReplaceEmptyPipeStrategy = /** @class */ (function () {
    function ReplaceEmptyPipeStrategy() {
    }
    /**
     * @param {?} value
     * @param {?} replaceValue
     * @return {?}
     */
    ReplaceEmptyPipeStrategy.prototype.transform = /**
     * @param {?} value
     * @param {?} replaceValue
     * @return {?}
     */
    function (value, replaceValue) {
        /** @type {?} */
        var replaceEmpty = new ReplaceEmptyPipe();
        return replaceEmpty.transform(value, replaceValue);
    };
    return ReplaceEmptyPipeStrategy;
}());
export { ReplaceEmptyPipeStrategy };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVwbGFjZS1lbXB0eS5waXBlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGJyaXNhbmV0L2lvbi8iLCJzb3VyY2VzIjpbImNvcmUvcGlwZXMvcmVwbGFjZS1lbXB0eS5waXBlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxxQ0FBcUMsQ0FBQztBQUd2RTtJQUFBO0lBS0EsQ0FBQzs7Ozs7O0lBSkMsNENBQVM7Ozs7O0lBQVQsVUFBVSxLQUFzQixFQUFFLFlBQW9COztZQUM5QyxZQUFZLEdBQUcsSUFBSSxnQkFBZ0IsRUFBRTtRQUMzQyxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLFlBQVksQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFDSCwrQkFBQztBQUFELENBQUMsQUFMRCxJQUtDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmVwbGFjZUVtcHR5UGlwZSB9IGZyb20gJy4uLy4uL2xpYi91dGlscy9waXBlcy9yZXBsYWNlLWVtcHR5JztcbmltcG9ydCB7IFBpcGVTdHJhdGVneSB9IGZyb20gJy4vcGlwZS1zdHJhdGVneSc7XG5cbmV4cG9ydCBjbGFzcyBSZXBsYWNlRW1wdHlQaXBlU3RyYXRlZ3kgaW1wbGVtZW50cyBQaXBlU3RyYXRlZ3kge1xuICB0cmFuc2Zvcm0odmFsdWU6IHN0cmluZyB8IG51bWJlciwgcmVwbGFjZVZhbHVlOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHJlcGxhY2VFbXB0eSA9IG5ldyBSZXBsYWNlRW1wdHlQaXBlKCk7XG4gICAgcmV0dXJuIHJlcGxhY2VFbXB0eS50cmFuc2Zvcm0odmFsdWUsIHJlcGxhY2VWYWx1ZSk7XG4gIH1cbn1cbiJdfQ==