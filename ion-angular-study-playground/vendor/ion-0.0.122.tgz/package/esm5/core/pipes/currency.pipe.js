/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { CurrencyPipe } from '@angular/common';
var CurrencyPipeStrategy = /** @class */ (function () {
    function CurrencyPipeStrategy() {
    }
    /**
     * @param {?} value
     * @return {?}
     */
    CurrencyPipeStrategy.prototype.transform = /**
     * @param {?} value
     * @return {?}
     */
    function (value) {
        /** @type {?} */
        var locale = 'en-US';
        /** @type {?} */
        var currencyPipe = new CurrencyPipe(locale);
        return currencyPipe.transform(value, 'BRL', 'symbol', '1.2-2');
    };
    return CurrencyPipeStrategy;
}());
export { CurrencyPipeStrategy };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3VycmVuY3kucGlwZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BicmlzYW5ldC9pb24vIiwic291cmNlcyI6WyJjb3JlL3BpcGVzL2N1cnJlbmN5LnBpcGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUcvQztJQUFBO0lBTUEsQ0FBQzs7Ozs7SUFMQyx3Q0FBUzs7OztJQUFULFVBQVUsS0FBYTs7WUFDZixNQUFNLEdBQUcsT0FBTzs7WUFDaEIsWUFBWSxHQUFHLElBQUksWUFBWSxDQUFDLE1BQU0sQ0FBQztRQUM3QyxPQUFPLFlBQVksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUNILDJCQUFDO0FBQUQsQ0FBQyxBQU5ELElBTUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDdXJyZW5jeVBpcGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgUGlwZVN0cmF0ZWd5IH0gZnJvbSAnLi9waXBlLXN0cmF0ZWd5JztcblxuZXhwb3J0IGNsYXNzIEN1cnJlbmN5UGlwZVN0cmF0ZWd5IGltcGxlbWVudHMgUGlwZVN0cmF0ZWd5IHtcbiAgdHJhbnNmb3JtKHZhbHVlOiBudW1iZXIpOiBzdHJpbmcge1xuICAgIGNvbnN0IGxvY2FsZSA9ICdlbi1VUyc7XG4gICAgY29uc3QgY3VycmVuY3lQaXBlID0gbmV3IEN1cnJlbmN5UGlwZShsb2NhbGUpO1xuICAgIHJldHVybiBjdXJyZW5jeVBpcGUudHJhbnNmb3JtKHZhbHVlLCAnQlJMJywgJ3N5bWJvbCcsICcxLjItMicpO1xuICB9XG59XG4iXX0=