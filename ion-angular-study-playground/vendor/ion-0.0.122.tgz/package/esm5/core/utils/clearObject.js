/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { isEmpty } from './isEmpty';
/**
 * @template T
 * @param {?} value
 * @return {?}
 */
export function clearObject(value) {
    Object.keys(value).forEach((/**
     * @param {?} key
     * @return {?}
     */
    function (key) {
        if (isNestedObj(value[key])) {
            clearObject(value[key]);
        }
        if (shouldDelete(value[key])) {
            delete value[key];
        }
    }));
    return value;
}
/**
 * @param {?} value
 * @return {?}
 */
function isNestedObj(value) {
    return value && !Array.isArray(value) && typeof value === 'object';
}
/**
 * @param {?} value
 * @return {?}
 */
function shouldDelete(value) {
    return ([null, undefined, ''].includes(value) ||
        Number.isNaN(value) ||
        (Array.isArray(value) && isEmpty(value)));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xlYXJPYmplY3QuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AYnJpc2FuZXQvaW9uLyIsInNvdXJjZXMiOlsiY29yZS91dGlscy9jbGVhck9iamVjdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQ0EsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLFdBQVcsQ0FBQzs7Ozs7O0FBRXBDLE1BQU0sVUFBVSxXQUFXLENBQWMsS0FBYztJQUNyRCxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU87Ozs7SUFBQyxVQUFDLEdBQUc7UUFDN0IsSUFBSSxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDM0IsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ3pCO1FBRUQsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDNUIsT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkI7SUFDSCxDQUFDLEVBQUMsQ0FBQztJQUNILE9BQU8sS0FBSyxDQUFDO0FBQ2YsQ0FBQzs7Ozs7QUFFRCxTQUFTLFdBQVcsQ0FBQyxLQUFjO0lBQ2pDLE9BQU8sS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLENBQUM7QUFDckUsQ0FBQzs7Ozs7QUFFRCxTQUFTLFlBQVksQ0FBQyxLQUFjO0lBQ2xDLE9BQU8sQ0FDTCxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUNyQyxNQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUNuQixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQ3pDLENBQUM7QUFDSixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2FmZUFueSB9IGZyb20gJy4uLy4uL2xpYi91dGlscy9zYWZlLWFueSc7XG5pbXBvcnQgeyBpc0VtcHR5IH0gZnJvbSAnLi9pc0VtcHR5JztcblxuZXhwb3J0IGZ1bmN0aW9uIGNsZWFyT2JqZWN0PFQgPSBTYWZlQW55Pih2YWx1ZTogU2FmZUFueSk6IFQge1xuICBPYmplY3Qua2V5cyh2YWx1ZSkuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgaWYgKGlzTmVzdGVkT2JqKHZhbHVlW2tleV0pKSB7XG4gICAgICBjbGVhck9iamVjdCh2YWx1ZVtrZXldKTtcbiAgICB9XG5cbiAgICBpZiAoc2hvdWxkRGVsZXRlKHZhbHVlW2tleV0pKSB7XG4gICAgICBkZWxldGUgdmFsdWVba2V5XTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gdmFsdWU7XG59XG5cbmZ1bmN0aW9uIGlzTmVzdGVkT2JqKHZhbHVlOiBTYWZlQW55KTogYm9vbGVhbiB7XG4gIHJldHVybiB2YWx1ZSAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jztcbn1cblxuZnVuY3Rpb24gc2hvdWxkRGVsZXRlKHZhbHVlOiBTYWZlQW55KTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgW251bGwsIHVuZGVmaW5lZCwgJyddLmluY2x1ZGVzKHZhbHVlKSB8fFxuICAgIE51bWJlci5pc05hTih2YWx1ZSkgfHxcbiAgICAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiYgaXNFbXB0eSh2YWx1ZSkpXG4gICk7XG59XG4iXX0=