export declare class IonSharedModule {
}
