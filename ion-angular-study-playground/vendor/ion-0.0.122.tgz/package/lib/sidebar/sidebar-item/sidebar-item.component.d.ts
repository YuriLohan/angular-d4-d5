import { EventEmitter } from '@angular/core';
import { IconType } from '../../core/types';
export declare class IonSidebarItemComponent {
    title: string;
    icon: IconType;
    selectable: boolean;
    selected: boolean;
    disabled: boolean;
    shrinkMode: boolean;
    sidebarClosed: boolean;
    inGroup: boolean;
    atClick: EventEmitter<MouseEvent>;
    onMouseDown(event: MouseEvent): void;
}
