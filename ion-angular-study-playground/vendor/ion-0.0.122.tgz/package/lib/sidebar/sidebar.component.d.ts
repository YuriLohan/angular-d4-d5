import { AfterViewChecked, ChangeDetectorRef, EventEmitter, TemplateRef } from '@angular/core';
import { IonSidebarProps } from '../core/types/sidebar';
export declare class IonSidebarComponent implements AfterViewChecked {
    private cdr;
    logo: string;
    logoAction?: () => void;
    items: IonSidebarProps['items'];
    closeOnSelect: boolean;
    shrinkMode: boolean;
    sidebarFooter?: TemplateRef<void>;
    keepShrunken: boolean;
    ionOnSidebarToggle: EventEmitter<boolean>;
    closed: boolean;
    constructor(cdr: ChangeDetectorRef);
    ngAfterViewChecked(): void;
    checkClikOnPageAccess: (event: any) => void;
    toggleSidebarVisibility(): void;
    itemSelected(itemIndex: number, event: MouseEvent): void;
    itemOnGroupSelected(groupIndex: number): void;
    groupSelected(groupIndex: number, event: MouseEvent): void;
    handleLogoClick(): void;
}
