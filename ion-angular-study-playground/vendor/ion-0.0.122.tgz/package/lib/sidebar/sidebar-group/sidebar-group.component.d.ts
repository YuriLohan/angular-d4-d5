import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { IconType } from '../../core/types';
import { Item } from '../../core/types/sidebar';
export declare class IonSidebarGroupComponent implements OnChanges {
    title: string;
    icon: IconType;
    items: Item[];
    selected: boolean;
    haveGroupAction: boolean;
    shrinkMode: boolean;
    sidebarClosed: boolean;
    atClick: EventEmitter<MouseEvent>;
    atGroupClick: EventEmitter<{}>;
    closed: boolean;
    headerIconHovered: boolean;
    changeIconHover(mouseEnter: boolean): void;
    toggleItemsVisibility(): void;
    itemSelected(itemIndex: number, event: MouseEvent): void;
    groupSelected(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private selectedChangedToFalse;
}
