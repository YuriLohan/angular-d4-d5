export declare class IonSidebarModule {
}
