import { OnInit } from '@angular/core';
import { AvatarType } from '../core/types/avatar';
import { SizeType } from '../core/types/size';
import { IconType } from '../core/types/icon';
export declare class IonAvatarComponent implements OnInit {
    type: AvatarType;
    size: SizeType;
    value?: string;
    image?: string;
    onErrorImage?: string;
    initials: string;
    icon: IconType;
    ngOnInit(): void;
    private getInitials;
}
