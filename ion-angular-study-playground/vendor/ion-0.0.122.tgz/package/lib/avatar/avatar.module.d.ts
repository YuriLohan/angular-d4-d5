export declare class IonAvatarModule {
}
