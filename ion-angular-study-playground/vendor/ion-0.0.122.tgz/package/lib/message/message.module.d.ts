export declare class IonMessageModule {
}
