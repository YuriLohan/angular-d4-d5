import { OnInit } from '@angular/core';
import { IconType } from '../core/types/icon';
export declare class IonMessageComponent implements OnInit {
    label: string;
    type: string;
    iconType?: IconType;
    setIcon(): void;
    ngOnInit(): void;
}
