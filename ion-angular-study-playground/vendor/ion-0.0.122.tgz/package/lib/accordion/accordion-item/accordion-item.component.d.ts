import { OnInit, EventEmitter, TemplateRef } from '@angular/core';
import { SafeAny } from '../../utils/safe-any';
export declare class IonAccordionItemComponent implements OnInit {
    templateHeader: TemplateRef<HTMLElement>;
    show?: boolean;
    data?: SafeAny;
    activeChange?: EventEmitter<void>;
    iconSize: number;
    ngOnInit(): void;
    toggle(): void;
}
