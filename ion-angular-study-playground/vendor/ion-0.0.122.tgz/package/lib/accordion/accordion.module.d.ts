export declare class IonAccordionModule {
}
