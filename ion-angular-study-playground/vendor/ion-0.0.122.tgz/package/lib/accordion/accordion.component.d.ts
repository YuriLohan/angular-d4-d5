import { TemplateRef, EventEmitter, OnInit } from '@angular/core';
import { AccordionItem } from '../core/types/accordion';
export declare class IonAccordionComponent implements OnInit {
    accordions: AccordionItem[];
    templateBody: TemplateRef<HTMLElement>;
    modeAccordion: boolean;
    templateHeader: TemplateRef<HTMLElement>;
    activeChange: EventEmitter<any>;
    ngOnInit(): void;
    toggle(index: number): void;
    closeAccordions(): void;
    validate(): void;
}
