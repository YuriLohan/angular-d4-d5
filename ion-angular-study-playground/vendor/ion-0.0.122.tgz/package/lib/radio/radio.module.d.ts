export declare class IonRadioModule {
}
