export declare class IonRadioComponent {
    label?: string;
    checked?: boolean;
    disabled?: boolean;
    check(): void;
}
