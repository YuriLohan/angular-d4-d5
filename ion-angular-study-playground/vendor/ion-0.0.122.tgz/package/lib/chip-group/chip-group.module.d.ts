export declare class IonChipGroupModule {
}
