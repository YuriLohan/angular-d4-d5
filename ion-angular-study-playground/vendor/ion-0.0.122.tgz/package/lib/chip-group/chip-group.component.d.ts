import { EventEmitter } from '@angular/core';
import { ChipEvent, ChipSize, IconDirection, IonChipProps, RightBadge } from '../core/types';
import { ChipInGroup } from '../core/types/chip-group';
import { DropdownItem } from '../core/types/dropdown';
export declare class IonChipGroupComponent {
    chips: ChipInGroup[];
    size?: ChipSize;
    infoBadge?: IonChipProps['infoBadge'];
    iconPosition?: IconDirection;
    rightBadge?: RightBadge;
    disabled: boolean;
    multiple: boolean;
    required: boolean;
    selected?: EventEmitter<ChipInGroup>;
    dropdown?: EventEmitter<DropdownItem[]>;
    selectChip(chipSelected: ChipInGroup): void;
    setChip(chipSelected: ChipInGroup): ChipInGroup;
    checkRequired(chipSelected: ChipInGroup): void;
    chipEvents(event: ChipEvent): void;
    dropdownEvents(options: DropdownItem[]): void;
    private clearChips;
}
