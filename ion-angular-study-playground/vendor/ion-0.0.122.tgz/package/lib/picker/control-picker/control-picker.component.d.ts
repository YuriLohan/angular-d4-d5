import { EventEmitter } from '@angular/core';
export declare type TypeEvents = 'previousYear' | 'previousMonth' | 'nextMonth' | 'nextYear' | 'changeMonth' | 'changeYear';
declare type Events = {
    type: TypeEvents;
    value?: string;
};
export interface ControlEvent {
    event?: Events;
}
export interface IonControlPickerComponentProps {
    month: string;
    year: string;
    controlPickerEvent?: EventEmitter<ControlEvent>;
}
export declare class IonControlPickerComponent {
    month: string;
    year: string;
    controlPickerEvent: EventEmitter<ControlEvent>;
    months: string[];
    showContainerToChooseMonth: boolean;
    showContainerToChooseYear: boolean;
    rangeYear: number[];
    handlePreviousYear(): void;
    handlePreviousMonth(): void;
    handleNextMonth(): void;
    handleNextYear(): void;
    setVisibleContainerToChooseMonth(visible: boolean): void;
    handleChangeMonth(monthNumber: string): void;
    setVisibleContainerToChooseYear(visible: boolean): void;
    handleChangeYear(year: string): void;
    setRangeYear(currentYear?: number): void;
    handleShowPreviousYears(): void;
    handleShowNextYears(): void;
}
export {};
