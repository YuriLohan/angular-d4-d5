import { EventEmitter } from '@angular/core';
export interface PreDefinedRangeConfig {
    label: string;
    duration: string;
    isFuture?: boolean;
}
export declare class IonPredefinedRangePickerComponent {
    config: PreDefinedRangeConfig[];
    definedRangePicker: EventEmitter<PreDefinedRangeConfig>;
    handlePreDefinedRange(event: PreDefinedRangeConfig): void;
}
