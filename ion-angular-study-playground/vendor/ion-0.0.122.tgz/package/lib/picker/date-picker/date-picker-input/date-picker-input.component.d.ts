import { EventEmitter } from '@angular/core';
import { SafeAny } from './../../../utils/safe-any';
export interface IonDatePickerInputComponentProps {
    date?: string;
    placeholder?: string;
    clearDate?: EventEmitter<SafeAny>;
}
export declare class IonDatePickerInputComponent {
    date?: string;
    rangePicker?: boolean;
    placeholder?: string;
    clearDate: EventEmitter<{}>;
    clearButtonConfig: {
        iconType: string;
        type: string;
        size: string;
    };
    clearDateValue(): void;
}
