import { AfterViewInit, EventEmitter } from '@angular/core';
import { IonDatePickerComponentProps } from '../../core/types/datepicker';
import { ControlEvent } from '../control-picker/control-picker.component';
import { UpdateLabelCalendar } from '../core/calendar-model';
import { Day } from '../core/day';
import { PreDefinedRangeConfig } from '../predefined-range-picker/predefined-range-picker.component';
export declare const DEFAULT_FINAL_FORMAT = "YYYY-MM-DD";
export declare const DEFAULT_INPUT_FORMAT = "DD/MM/YYYY";
export declare class IonDatepickerComponent implements AfterViewInit {
    format: string;
    formatInDateInput: IonDatePickerComponentProps['formatInDateInput'];
    rangePicker: boolean;
    predefinedRanges?: PreDefinedRangeConfig[];
    direction: IonDatePickerComponentProps['direction'];
    disabledDate: IonDatePickerComponentProps['disabledDate'];
    event: EventEmitter<string[]>;
    currentDate: string[];
    inputDate: string;
    showDatepicker: boolean;
    calendarMonth: string;
    calendarYear: string;
    selectedDay: Day[];
    calendarControlAction: string;
    goToMonth: string;
    goToYear: string;
    setVisibleCalendar(visible: boolean): void;
    ngAfterViewInit(): void;
    events({ event }: ControlEvent): void;
    updateLabelCalendar({ month, year }: UpdateLabelCalendar): void;
    getFinalFormatDate(data: Day[]): string[];
    /**
     * @param predefinedRange - defines ranges.
     * @param predefinedRange.label - name of the range.
     * @param predefinedRange.duration - period of the range, it has to be in ISO 8601 format
     * @param [predefinedRange.isFuture=false]  - defines if the period is previously or posteriorly
     * @description - This function is called when a predefined range is selected.
     * @returns void
     */
    onSelectPredefinedRange(predefinedRange: PreDefinedRangeConfig): void;
    dateSelected(data: Day[]): void;
    clearDate(): void;
}
