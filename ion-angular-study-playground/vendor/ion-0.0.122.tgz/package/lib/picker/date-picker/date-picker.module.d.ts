export declare class IonDatePickerModule {
}
