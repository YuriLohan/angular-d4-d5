import { Day } from './day';
import { Month } from './month';
export declare class Calendar {
    monthNumber: any;
    lang: string;
    today: Day;
    month: Month;
    year: number;
    weekDays: {}[];
    constructor(year?: any, monthNumber?: any, lang?: string);
    readonly isLeapYear: boolean;
    getMonth(monthNumber: any): Month;
    getPreviousMonth(): Month;
    getNextMonth(): Month;
    goToDate(monthNumber: number, year: number): void;
    goToPreviousYear(monthNumber?: number): void;
    goToNextYear(monthNumber?: number): void;
    goToNextMonth(): void;
    goToPreviousMonth(): void;
    getDay(day: number): Day;
    getLastMonthFinalDays(): number;
    getWeekDaysElementStrings(): string[];
}
