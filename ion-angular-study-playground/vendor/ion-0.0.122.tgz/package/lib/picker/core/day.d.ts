export declare class Day {
    lang: string;
    Date: Date;
    date: number;
    day: string;
    dayNumber: number;
    dayShort: string;
    year: number;
    yearShort: string;
    month: string;
    monthShort: string;
    monthNumber: number;
    timestamp: number;
    week: number;
    disabled?: boolean;
    isDayCurrentMonth?: boolean;
    isToday?: boolean;
    isBetweenRange?: boolean;
    isRangeInitialLimit?: boolean;
    isRangeFinalLimit?: boolean;
    constructor(date?: Date, lang?: string);
    getWeekNumber(date: Date): number;
    format(formatStr: string): string;
    getAriaLabel(): string;
}
