import { Day } from './day';
export declare class Month {
    private date?;
    lang: string;
    day: Day;
    MonthsSize: number[];
    February: number;
    name: string;
    number: number;
    year: number;
    numberOfDays: number;
    constructor(date?: any, lang?: string);
    getDay(date: any): Day;
}
