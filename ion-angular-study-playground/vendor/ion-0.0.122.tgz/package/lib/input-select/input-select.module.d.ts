export declare class IonInputSelectModule {
}
