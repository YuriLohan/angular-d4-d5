import { EventEmitter, OnInit } from '@angular/core';
import { SelectOption, ValueToEmmit } from '../core/types/input-select';
export declare const defaultSelectOptions: SelectOption[];
export declare class IonInputSelectComponent implements OnInit {
    name?: string;
    disabled: boolean;
    value: string;
    secondValue: string;
    selectOptions: SelectOption[];
    valid: boolean | null;
    valueChange: EventEmitter<ValueToEmmit>;
    dropdownVisible: boolean;
    currentOption: SelectOption;
    handleSelect(selectedOption: SelectOption[]): void;
    handleClick(): void;
    handleChange(): void;
    closeDropdown(): void;
    ngOnInit(): void;
    private clearInputs;
    private toggleDropdownVisibility;
    private getCurrentOption;
}
