export declare class IonPaginationModule {
}
