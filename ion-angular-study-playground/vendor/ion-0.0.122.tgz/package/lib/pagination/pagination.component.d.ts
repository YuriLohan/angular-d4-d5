import { EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { DropdownItem } from '../core/types/dropdown';
import { IonPaginationProps, Page, PageEvent } from '../core/types/pagination';
export declare const ITEMS_PER_PAGE_DEFAULT = 10;
export declare const LIST_OF_PAGE_OPTIONS: number[];
export declare class IonPaginationComponent implements OnChanges, OnInit {
    total: IonPaginationProps['total'];
    itemsPerPage: IonPaginationProps['itemsPerPage'];
    pageSizeOptions: IonPaginationProps['pageSizeOptions'];
    size: IonPaginationProps['size'];
    allowChangeQtdItems: IonPaginationProps['allowChangeQtdItems'];
    loading: boolean;
    page: number;
    openItemsPerPageAbove?: boolean;
    events: EventEmitter<PageEvent>;
    optionsPage?: DropdownItem[];
    labelPerPage: string;
    pages: Page[];
    isAdvanced: boolean;
    moreBtnsConfig: {
        left: {
            hover: boolean;
            visible: boolean;
        };
        right: {
            hover: boolean;
            visible: boolean;
        };
    };
    currentVisibleButtons: Page[];
    changeIconHover(side: string, value: boolean): void;
    updateMoreBtnsVisibility(): void;
    changeItemsPerPage(itemsSelected: DropdownItem[]): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    setPage(page?: number): void;
    selectPageOnClick(pageNumber: number): void;
    selectPage(pageNumber?: number, emitEvent?: boolean): void;
    updateIsAdvanced(): void;
    hasPrevious(): boolean;
    hasNext(): boolean;
    previous(): void;
    next(): void;
    remountPages(emitEvent?: boolean): void;
    totalPages(): number;
    getSelectedItemsPerPageLabel(options: DropdownItem[]): string;
    nextVisibleButtons(): Page[];
    getStartPageIndex(currentIndex: number): number;
    getLastPageIndex(currentIndex: number, startPageIndex: number): number;
    jumpPagesForward(): void;
    jumpPagesBackward(): void;
    private createPages;
    private currentPage;
    private inLastPage;
    private inFirstPage;
    private generateLabel;
    private getOptionsPage;
    private isASelectedOption;
}
