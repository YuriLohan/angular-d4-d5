export declare class IonButtonModule {
}
