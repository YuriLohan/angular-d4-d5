import { AfterViewInit, ChangeDetectorRef, ComponentFactoryResolver, EventEmitter, OnDestroy, ViewContainerRef } from '@angular/core';
import { IonCard, CardEvent } from '../core/types/card';
export declare class IonCardComponent implements AfterViewInit, OnDestroy {
    private resolverFactory;
    private cdr;
    configuration: IonCard;
    events: EventEmitter<CardEvent>;
    body: ViewContainerRef;
    footer: ViewContainerRef;
    private indexOfChipSelected;
    constructor(resolverFactory: ComponentFactoryResolver, cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    cardEvent(event: CardEvent): void;
    isChipSelected(chipIndex: number): boolean;
}
