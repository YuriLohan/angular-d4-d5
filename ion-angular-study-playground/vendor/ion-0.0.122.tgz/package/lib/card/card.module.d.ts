export declare class IonCardModule {
}
