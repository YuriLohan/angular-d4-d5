export declare class IonRowComponent {
}
