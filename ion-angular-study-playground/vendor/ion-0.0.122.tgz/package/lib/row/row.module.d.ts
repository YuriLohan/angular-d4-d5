export declare class IonRowModule {
}
