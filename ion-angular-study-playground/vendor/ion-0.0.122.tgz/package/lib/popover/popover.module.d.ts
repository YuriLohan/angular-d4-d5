export declare class IonPopoverModule {
}
