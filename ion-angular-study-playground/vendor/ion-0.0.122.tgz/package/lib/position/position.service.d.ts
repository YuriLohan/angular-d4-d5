import { Subject } from 'rxjs';
export declare enum IonPositions {
    TOP_RIGHT = "topRight",
    TOP_CENTER = "topCenter",
    TOP_LEFT = "topLeft",
    RIGHT_TOP = "rightTop",
    RIGHT_CENTER = "rightCenter",
    RIGHT_BOTTOM = "rightBottom",
    LEFT_TOP = "leftTop",
    LEFT_CENTER = "leftCenter",
    LEFT_BOTTOM = "leftBottom",
    BOTTOM_RIGHT = "bottomRight",
    BOTTOM_CENTER = "bottomCenter",
    BOTTOM_LEFT = "bottomLeft"
}
export declare type ElementPositions = {
    [key in IonPositions]: Pick<DOMRect, 'left' | 'top'>;
};
export declare type NewPosition = {
    key: IonPositions;
} & Pick<DOMRect, 'left' | 'top'>;
export declare type GetPositionsCallback = (props: GetPositionsCallbackProps) => ElementPositions;
export interface GetPositionsCallbackProps {
    host: DOMRect;
    element: DOMRect;
    arrowAtCenter: boolean;
}
export declare type RepositionData = {
    componentCoordinates: Partial<DOMRect>;
    hostPosition: Partial<DOMRect>;
    screenWidth: number;
    screenHeight: number;
};
export declare type PositionsChecks = {
    [x in IonPositions]?: boolean;
};
export declare class IonPositionService {
    readonly reposition: Subject<{}>;
    private hostPosition;
    private componentCoordinates;
    private elementPadding;
    private choosedPosition;
    private currentPosition;
    private pointAtCenter;
    private autoReposition;
    setElementPadding(padding: number): void;
    setHostPosition(position: DOMRect): void;
    setcomponentCoordinates(coordinates: DOMRect): void;
    setChoosedPosition(position: unknown): void;
    getCurrentPosition(): unknown;
    setPointAtCenter(value: boolean): void;
    setAutoReposition(value: boolean): void;
    getNewPosition(getPositionCallback: GetPositionsCallback): NewPosition;
    checkPositions(availablePositions: ElementPositions): keyof PositionsChecks;
    getPositions(): PositionsChecks;
    emitReposition(): void;
    private atRightEdge;
    private atBottomEdge;
    private atLeftEdge;
    private atTopEdge;
}
