import { OnChanges, OnInit, SimpleChanges, TemplateRef } from '@angular/core';
import { StatusType } from '../core/types';
import { IconType } from '../core/types/icon';
export declare class IonAlertComponent implements OnInit, OnChanges {
    message: string | TemplateRef<void>;
    type?: StatusType;
    closable?: boolean;
    hideBackground?: boolean;
    noRadius?: boolean;
    description?: string;
    private ionAlert;
    iconType: IconType;
    hasPlainText: boolean;
    closeEvent(): void;
    setIcon(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
}
