export declare class IonAlertModule {
}
