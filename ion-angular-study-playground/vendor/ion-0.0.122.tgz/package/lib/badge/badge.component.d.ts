import { OnChanges, OnInit } from '@angular/core';
import { BadgeType } from '../core/types/badge';
export declare class IonBadgeComponent implements OnChanges, OnInit {
    label?: string;
    value?: number;
    type: BadgeType;
    valueInBadge: string;
    ngOnInit(): void;
    ngOnChanges(): void;
    formatValue(): string;
    private exists;
    private limitValue;
}
