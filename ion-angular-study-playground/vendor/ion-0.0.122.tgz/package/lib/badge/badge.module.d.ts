export declare class IonBadgeModule {
}
