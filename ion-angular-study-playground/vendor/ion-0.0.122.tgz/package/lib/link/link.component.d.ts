import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FontSize, IconSide, IconType, LinkTarget } from '../core/types';
export declare class IonLinkComponent implements OnChanges {
    label: string;
    icon: IconType;
    iconSide: IconSide;
    size: FontSize;
    bold: boolean;
    disabled: boolean;
    target: LinkTarget;
    link?: string;
    ionOnClick: EventEmitter<void>;
    iconSize: number;
    onClick(): void;
    ngOnChanges(changes: SimpleChanges): void;
}
