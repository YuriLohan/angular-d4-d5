export declare class IonLinkModule {
}
