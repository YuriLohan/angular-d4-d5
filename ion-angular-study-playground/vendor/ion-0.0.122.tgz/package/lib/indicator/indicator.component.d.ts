import { EventEmitter } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { IonIndicatorButtonConfiguration } from '../core/types/indicator';
import { IonModalService } from './../modal/modal.service';
import { IonIconProps } from '../core/types';
export declare class IonIndicatorComponent {
    private sanitizer;
    private ionModalService;
    title: string;
    headerIcon?: Pick<IonIconProps, 'type' | 'color'>;
    tooltipText: string;
    secondValueTooltipText: string;
    value: number | string;
    secondValue: number | string;
    buttonConfig: IonIndicatorButtonConfiguration;
    preview: boolean;
    loading: boolean;
    error: boolean;
    ionClick: EventEmitter<{}>;
    modalEvent: EventEmitter<unknown>;
    safeUrl: SafeResourceUrl;
    private buttonActions;
    constructor(sanitizer: DomSanitizer, ionModalService: IonModalService);
    handleButtonClick(type: string): void;
    private sanitizeUrl;
    private emitButtonClick;
    private redirectTo;
    private openModal;
}
