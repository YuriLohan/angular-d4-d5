export declare class IonIndicatorModule {
}
