import { InfoBadgeSize, InfoBadgeStatus } from '../core/types/info-badge';
import { IconType } from '../core/types/icon';
export declare class IonInfoBadgeComponent {
    variant: InfoBadgeStatus;
    icon?: IconType;
    text?: string;
    size?: InfoBadgeSize;
}
