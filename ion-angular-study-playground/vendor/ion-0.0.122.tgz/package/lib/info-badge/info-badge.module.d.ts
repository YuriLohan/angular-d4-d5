export declare class IonInfoBadgeModule {
}
