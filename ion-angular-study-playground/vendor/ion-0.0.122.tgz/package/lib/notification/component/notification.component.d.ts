import { ElementRef, EventEmitter, OnInit } from '@angular/core';
import { IconType } from '../../core/types/icon';
import { NotificationProps } from '../../core/types/notification';
export declare class IonNotificationComponent implements OnInit {
    title: NotificationProps['title'];
    message: NotificationProps['message'];
    icon?: NotificationProps['icon'];
    type?: NotificationProps['type'];
    fixed?: NotificationProps['fixed'];
    fadeIn?: NotificationProps['fadeIn'];
    fadeOut?: NotificationProps['fadeOut'];
    notification: ElementRef;
    ionOnClose: EventEmitter<void>;
    private timer$;
    getIcon(): IconType;
    getClass(): string;
    timeByWords(message: string): number;
    closeNotification(): void;
    closeAuto(closeIn?: number): void;
    mouseEnter(): void;
    mouseLeave(): void;
    setClass(): string;
    ngOnInit(): void;
}
