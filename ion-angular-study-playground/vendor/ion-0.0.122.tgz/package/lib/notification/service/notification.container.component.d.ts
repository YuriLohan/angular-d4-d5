import { IonNotificationComponent } from '../component/notification.component';
import { ComponentRef, Renderer2, ElementRef } from '@angular/core';
export declare class IonNotificationContainerComponent {
    private renderer;
    private element;
    private notificationRefControl;
    constructor(renderer: Renderer2, element: ElementRef);
    addNotification(notification: ComponentRef<IonNotificationComponent>, maxStack: number): void;
    removeNotification(notification: ElementRef): void;
}
