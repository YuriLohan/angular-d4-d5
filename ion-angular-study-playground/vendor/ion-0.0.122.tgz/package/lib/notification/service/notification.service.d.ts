import { NotificationConfigOptions, NotificationServiceConfig } from './../../core/types/notification';
import { IonNotificationComponent } from './../component/notification.component';
import { ComponentRef, ComponentFactoryResolver, ApplicationRef, Injector } from '@angular/core';
import { SafeAny } from './../../utils/safe-any';
export declare class IonNotificationService {
    private document;
    private componentFactoryResolver;
    private appRef;
    private injector;
    notificationServiceConfig: NotificationServiceConfig;
    private notificationContainerComponentRef;
    private componentSubscriber;
    constructor(document: SafeAny, componentFactoryResolver: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector);
    success(title: string, message: string, options?: NotificationConfigOptions, closeEventCall?: () => void): void;
    info(title: string, message: string, options?: NotificationConfigOptions, closeEventCall?: () => void): void;
    warning(title: string, message: string, options?: NotificationConfigOptions, closeEventCall?: () => void): void;
    error(title: string, message: string, options?: NotificationConfigOptions, closeEventCall?: () => void): void;
    addCloseEventEmitter(notification: ComponentRef<IonNotificationComponent>, closeEvent: () => void): void;
    private createComponentView;
    private createNotificationContainer;
    private createNotificationInstance;
    private showNotification;
    private configNotification;
    private instanceNotification;
}
