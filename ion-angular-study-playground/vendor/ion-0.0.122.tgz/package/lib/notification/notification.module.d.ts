export declare class IonNotificationModule {
}
