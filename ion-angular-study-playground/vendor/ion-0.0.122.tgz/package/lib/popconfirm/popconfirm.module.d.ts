export declare class IonPopConfirmModule {
}
