import { Subject } from 'rxjs';
import { PopConfirmProps } from '../core/types/popconfirm';
export declare class IonPopConfirmComponent {
    ionPopConfirmTitle: string;
    ionPopConfirmDesc: string;
    ionPopConfirmType: PopConfirmProps['ionPopConfirmType'];
    ionConfirmText: PopConfirmProps['ionConfirmText'];
    ionCancelText: PopConfirmProps['ionCancelText'];
    readonly ionOnConfirm: Subject<void>;
    readonly ionOnClose: Subject<void>;
    onClickOutside(): void;
    handleConfirm(): void;
    close(): void;
}
