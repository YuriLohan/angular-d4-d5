import { ApplicationRef, ComponentFactoryResolver, EventEmitter, Injector, OnDestroy, ViewContainerRef } from '@angular/core';
import { PopConfirmProps, StatusType } from '../core/types';
import { SafeAny } from './../utils/safe-any';
export interface PopPosition {
    top: number;
    left: number;
    width: number;
    hostHeight?: number;
}
export interface PopOffset {
    top: number;
    left: number;
    width: number;
    screenOffset: number;
}
export declare class IonPopConfirmDirective implements OnDestroy {
    private document;
    private componentFactoryResolver;
    private appRef;
    private injector;
    private readonly viewRef;
    ionPopConfirmTitle: string;
    ionPopConfirmDesc: string;
    ionPopConfirmType: StatusType;
    ionConfirmText: PopConfirmProps['ionConfirmText'];
    ionCancelText: PopConfirmProps['ionCancelText'];
    ionPopConfirmCloseOnScroll: PopConfirmProps['ionPopConfirmCloseOnScroll'];
    ionOnConfirm: EventEmitter<void>;
    ionOnClose: EventEmitter<void>;
    private IonPopConfirmComponentRef;
    private isBottomIcon;
    private marginBetweenComponents;
    constructor(document: SafeAny, componentFactoryResolver: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector, viewRef: ViewContainerRef);
    open(): void;
    closePopConfirm(): void;
    setPosition(element: HTMLElement, docWidth: number, position: PopPosition): PopOffset;
    isBiggerThenWindow(position: PopPosition, elementSize: number): boolean;
    setUpPositionPopconfirm(position: any, elementSize: any): void;
    closeAllPopsConfirm(): void;
    createPopConfirm(): void;
    setStyle(element: HTMLElement, offset: PopOffset): void;
    elementChildIsEnabled(element: HTMLElement): boolean;
    elementChildIsLoading(element: HTMLElement): boolean;
    hostElementIsEnabled(element: HTMLElement): boolean;
    elementsAreEnabled(element: HTMLElement): boolean;
    ngOnDestroy(): void;
    onClick(): void;
    onScroll({ target }: Event): void;
}
