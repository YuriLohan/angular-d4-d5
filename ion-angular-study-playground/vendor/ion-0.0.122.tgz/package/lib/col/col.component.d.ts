export declare class IonColComponent {
}
