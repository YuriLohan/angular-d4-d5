export declare class IonColModule {
}
