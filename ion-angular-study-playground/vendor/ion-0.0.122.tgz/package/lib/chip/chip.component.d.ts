import { EventEmitter, OnInit, DoCheck, AfterViewInit } from '@angular/core';
import { BadgeType, DropdownItem, DropdownParams, IconType, InfoBadgeStatus } from '../core/types';
export declare type ChipSize = 'sm' | 'md';
export declare type IconDirection = 'right' | 'left';
interface ChipEvent {
    selected: boolean;
    disabled: boolean;
    closeDropdown?: boolean;
}
export interface IonChipProps {
    label: string;
    disabled?: boolean;
    selected?: boolean;
    size?: ChipSize;
    events?: EventEmitter<ChipEvent>;
    options?: DropdownItem[];
    icon?: string;
    multiple?: boolean;
    infoBadge?: InfoBadgeStatus;
    iconPosition?: IconDirection;
    rightBadge?: RightBadge;
    showToggle?: boolean;
    dropdownEvents?: EventEmitter<DropdownItem[]>;
    dropdownSearchConfig?: Pick<DropdownParams, 'searchOptions' | 'enableSearch'>;
    dropdownSearchEvents?: EventEmitter<string>;
}
declare type Badge = {
    value: number;
};
interface RightBadge {
    label: string;
    type: BadgeType;
}
export declare class ChipComponent implements OnInit, AfterViewInit, DoCheck {
    label: string;
    disabled: boolean;
    selected: boolean;
    size?: ChipSize;
    icon?: IconType;
    showDropdown: boolean;
    dropdownSearchConfig: IonChipProps['dropdownSearchConfig'];
    options: DropdownItem[];
    multiple: boolean;
    infoBadge?: IonChipProps['infoBadge'];
    iconPosition?: IconDirection;
    rightBadge?: RightBadge;
    showToggle: boolean;
    required: boolean;
    chipGroup: boolean;
    chipGroupRequired: boolean;
    events: EventEmitter<ChipEvent>;
    dropdownEvents: EventEmitter<DropdownItem[]>;
    dropdownSearchEvents: EventEmitter<string>;
    dropdownWithIcon: boolean;
    dropdownId: string;
    chipId: string;
    badge: Badge;
    tempFilter: DropdownItem[];
    placeholder: string;
    iconPlaceholder?: IconType;
    firstCheck: boolean;
    select(): void;
    toggleDropdown(): void;
    clearBadgeValue(): void;
    selectDropdownItem(selecteds: DropdownItem[]): void;
    setPlaceHolder(label: string, icon: IconType): void;
    dropdownSearchChange(value: string): void;
    ngOnInit(): void;
    generateId: (name: string) => string;
    ngDoCheck(): void;
    getSelectedOptions(): DropdownItem[];
    ngAfterViewInit(): void;
    updateLabel(): void;
    firstUpdateLabel(): void;
    closeDropdown(): void;
    private setBadgeValue;
    private updateDropdownWithIcon;
}
export {};
