export declare class IonChipModule {
}
