export declare class IonModule {
}
