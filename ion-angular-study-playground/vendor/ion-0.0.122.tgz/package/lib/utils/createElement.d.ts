export declare type CreateElementProps = {
    type: string;
    text: string;
    attributes: Attribute[];
};
declare type Attribute = {
    key: string;
    value: string;
};
export declare const createElement: ({ text, type, attributes, }: CreateElementProps) => HTMLElement;
export {};
