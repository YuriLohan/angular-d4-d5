export declare const DROPDOWN_SELECTOR = "#dropdown-";
export declare const DROPDOWN_SEARCH_SELECTOR = " .dropdown-search";
