import { Observable } from 'rxjs';
export declare const setTimer: (time?: number) => Observable<number>;
