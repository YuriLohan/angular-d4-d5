declare const debounce: <T extends (...args: any[]) => ReturnType<T>>(callback: T, timeout: number) => (...args: Parameters<T>) => void;
export default debounce;
