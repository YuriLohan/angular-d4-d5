export declare const MOUSE_BUTTONS: {
    LEFT: number;
    MIDDLE: number;
    RIGHT: number;
};
