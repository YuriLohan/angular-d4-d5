export declare type fadeInDirection = 'fadeIn' | 'fadeInUp' | 'fadeInRigth' | 'fadeInLeft' | 'fadeInDown';
export declare type fadeOutDirection = 'fadeOutUp' | 'fadeOutRigth' | 'fadeOutLeft' | 'fadeOutDown' | 'fadeOut';
