export declare const ID_SELECTOR = "#";
export declare const COOLDOWN_TIME = 400;
export declare const generateIDs: (prefix: string, testid: string) => string;
