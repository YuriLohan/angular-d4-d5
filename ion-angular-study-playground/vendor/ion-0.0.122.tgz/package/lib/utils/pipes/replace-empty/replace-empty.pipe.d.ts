import { PipeTransform } from '@angular/core';
import { SafeAny } from '../../safe-any';
export declare class ReplaceEmptyPipe implements PipeTransform {
    transform(value: SafeAny, replaceValue: string): string;
}
