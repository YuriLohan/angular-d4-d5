import { PipeTransform } from '@angular/core';
export declare class EllipsisPipe implements PipeTransform {
    transform(value: string, limit: number): string;
}
