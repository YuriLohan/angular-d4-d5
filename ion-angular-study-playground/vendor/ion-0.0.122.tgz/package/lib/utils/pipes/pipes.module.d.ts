export declare class PipesModule {
}
