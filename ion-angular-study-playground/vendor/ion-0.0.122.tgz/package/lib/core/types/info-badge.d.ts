import { StatusType } from './status';
import { IconType } from './icon';
export declare type InfoBadgeStatus = StatusType | 'primary';
export declare type InfoBadgeSize = 'sm' | 'md';
export interface InfoBadgeProps {
    variant: InfoBadgeStatus;
    icon?: IconType;
    text?: string;
    size?: InfoBadgeSize;
}
