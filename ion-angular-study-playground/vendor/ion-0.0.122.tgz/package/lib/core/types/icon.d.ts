import { iconsPaths } from '../../icon/svgs/icons';
export declare enum Highlight {
    SIMPLE = "simple",
    DOUBLE = "double",
    NONE = "none"
}
export declare type ContainerStyle = {
    size: string;
    color: string;
};
export declare type IconType = keyof typeof iconsPaths;
export declare type IconDirection = 'right' | 'left';
export interface IonIconProps {
    type: IconType;
    size?: number;
    color?: string;
    highlight?: Highlight;
}
