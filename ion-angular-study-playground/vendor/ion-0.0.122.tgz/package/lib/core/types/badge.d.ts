import { IconType } from './icon';
export declare type BadgeType = 'primary' | 'secondary' | 'neutral' | 'negative' | 'warning';
export interface BadgeProps {
    label?: string;
    value?: number;
    icon?: IconType;
    type: BadgeType;
}
