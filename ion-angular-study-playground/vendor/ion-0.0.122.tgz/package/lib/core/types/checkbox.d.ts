import { EventEmitter } from '@angular/core';
export declare enum CheckBoxEvent {
    checked = "checked",
    enabled = "unchecked",
    indeterminate = "indeterminate"
}
export declare const StateChange: {
    enabled: string;
    checked: string;
    indeterminate: string;
};
export interface CheckboxReturn {
    state: CheckBoxEvent;
    value?: string;
}
export interface CheckBoxProps {
    label?: string;
    disabled?: boolean;
    state?: CheckBoxStates;
    ionClick?: EventEmitter<CheckBoxEvent>;
    value?: string;
}
export declare type CheckBoxStates = keyof typeof CheckBoxEvent;
