export declare type DirectionType = 'horizontal' | 'vertical';
export declare type BorderDirectionType = 'left' | 'right' | 'top' | 'bottom';
