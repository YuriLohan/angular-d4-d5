import { EventEmitter } from '@angular/core';
declare type FormatDateInput = 'YYYY-MM-DD' | 'DD/MM/YYYY';
export declare enum CalendarDirection {
    topLeft = "TOPLEFT",
    topRight = "TOPRIGHT",
    bottomLeft = "BOTTOMLEFT",
    bottomRight = "BOTTOMRIGHT"
}
export interface IonDatePickerComponentProps {
    format?: string;
    formatInDateInput?: FormatDateInput;
    rangePicker?: boolean;
    direction?: CalendarDirection;
    disabledDate?: (currentDate: Date) => boolean;
    event?: EventEmitter<string>;
}
export {};
