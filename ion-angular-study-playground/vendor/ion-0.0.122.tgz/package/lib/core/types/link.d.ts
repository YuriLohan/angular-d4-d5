import { EventEmitter } from '@angular/core';
import { IconType } from './icon';
export declare type FontSize = 'sm' | 'md';
export declare type IconSide = 'left' | 'right';
export declare type LinkTarget = '_blank' | '_self' | '_parent' | '_top';
export interface IonLinkProps {
    label?: string;
    icon?: IconType;
    iconSide?: IconSide;
    size?: FontSize;
    bold?: boolean;
    disabled?: boolean;
    target?: LinkTarget;
    link?: string;
    ionOnClick?: EventEmitter<void>;
}
