import { DirectionType } from '../core/types';
import { DividerType } from '../core/types/divider';
export declare class IonDividerComponent {
    label: string;
    direction?: DirectionType;
    type?: DividerType;
    margin?: boolean;
}
