export declare class IonDividerModule {
}
