import { ElementRef, EventEmitter } from '@angular/core';
export declare class ClickOutsideDirective {
    private elementRef;
    clickOutside: EventEmitter<null>;
    private firstOpen;
    constructor(elementRef: ElementRef);
    onClick(targetElement: HTMLElement): void;
}
