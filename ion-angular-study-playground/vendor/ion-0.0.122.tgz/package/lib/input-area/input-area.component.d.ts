import { EventEmitter } from '@angular/core';
export declare class IonInputAreaComponent {
    cols: string;
    rows: string;
    disabled: boolean;
    value: string;
    placeholder?: string;
    valueChange: EventEmitter<string>;
    onChange(value: string): void;
}
