export declare class IonInputAreaModule {
}
