export declare class IonComponent {
}
