export declare class IonNoDataModule {
}
