import { IconType } from '../core/types';
export declare class IonNoDataComponent {
    iconType: IconType;
    label: string;
}
