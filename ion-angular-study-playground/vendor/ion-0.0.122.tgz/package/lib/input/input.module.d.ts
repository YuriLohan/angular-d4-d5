export declare class IonInputModule {
}
