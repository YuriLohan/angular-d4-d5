import { EventEmitter, OnInit } from '@angular/core';
import { IonButtonProps } from '../core/types';
import { IconDirection, IconType } from '../core/types/icon';
import { InputType } from '../core/types/input';
export declare class IonInputComponent implements OnInit {
    placeholder?: string;
    button: string;
    iconInput: IconType;
    disabled: boolean;
    iconDirection?: IconDirection;
    valid: boolean;
    invalid: boolean;
    errorMsg?: string;
    inputButton: boolean;
    inputButtonConfig?: IonButtonProps;
    value: string;
    inputType: InputType;
    clearButton: boolean;
    readonly: boolean;
    maxLength?: string | number | null;
    valueChange: EventEmitter<string>;
    clickButton: EventEmitter<{}>;
    ngOnInit(): void;
    onChange(value: string): void;
    handleClick(): void;
    clearInput(): void;
    isClearButtonVisible(): boolean;
    private checkAndSetButtonSize;
}
