import { AfterViewInit, ElementRef } from '@angular/core';
import { ColorScheme, HeadingSize, HeadingType, HeadingWeight } from '../../core/types/typography';
export declare class IonHeadingComponent implements AfterViewInit {
    text: string;
    type: HeadingType;
    weight?: HeadingWeight;
    colorScheme?: ColorScheme;
    size?: HeadingSize;
    heading: ElementRef;
    ngAfterViewInit(): void;
    private makeElement;
    private addClass;
    private appendElement;
}
