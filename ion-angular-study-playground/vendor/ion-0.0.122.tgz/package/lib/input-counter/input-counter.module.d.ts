export declare class IonInputCounterModule {
}
