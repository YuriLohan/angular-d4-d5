import { EventEmitter, OnInit } from '@angular/core';
import { IonInputCount } from '../core/types';
export declare class IonInputCounterComponent implements OnInit {
    inputSize: IonInputCount['inputSize'];
    maxValue?: number;
    minValue: number;
    disabled: boolean;
    count: number;
    maxDigits: number;
    changedValue: EventEmitter<{}>;
    ngOnInit(): void;
    emitEvent(): void;
    countDecrement(): void;
    countIncrement(): void;
    changeCount(count: string): void;
    onBlurInput(): void;
    private getValidCount;
}
