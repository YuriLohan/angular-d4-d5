export declare class IonRadioGroupModule {
}
