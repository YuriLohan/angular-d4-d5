import { EventEmitter } from '@angular/core';
import { SafeAny } from '../utils/safe-any';
import { RadioOptions } from '../core/types/radio-group';
export declare class IonRadioGroupComponent {
    name: string;
    options: RadioOptions[];
    value: SafeAny;
    valueChange: EventEmitter<any>;
    setValue(optionValue: SafeAny): void;
}
