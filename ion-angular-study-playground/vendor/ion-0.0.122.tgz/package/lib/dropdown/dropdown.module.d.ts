export declare class IonDropdownModule {
}
