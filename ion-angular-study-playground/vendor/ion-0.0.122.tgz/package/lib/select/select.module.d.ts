export declare class IonSelectModule {
}
