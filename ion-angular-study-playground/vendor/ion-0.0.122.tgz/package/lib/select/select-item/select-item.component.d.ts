import { EventEmitter } from '@angular/core';
export declare class IonSelectItemComponent {
    label: string;
    disabled: boolean;
    unselect: EventEmitter<void>;
    onUnselect(): void;
}
