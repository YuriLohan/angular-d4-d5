export declare class DefaultImageDirective {
    src: string;
    default: string;
    width: string;
    height: string;
    updateUrl(): void;
}
