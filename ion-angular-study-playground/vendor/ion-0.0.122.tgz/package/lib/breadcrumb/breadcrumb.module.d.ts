export declare class IonBreadcrumbModule {
}
