import { EventEmitter, OnChanges } from '@angular/core';
import { DropdownItem } from '../core/types/dropdown';
export interface BreadcrumbItem {
    label: string;
    link: string;
}
export interface BreadcrumbProps {
    breadcrumbs: BreadcrumbItem[];
    selected: EventEmitter<BreadcrumbItem>;
    truncate?: boolean;
}
export declare class IonBreadcrumbComponent implements OnChanges {
    breadcrumbs: BreadcrumbProps['breadcrumbs'];
    truncate: BreadcrumbProps['truncate'];
    selected: EventEmitter<BreadcrumbItem>;
    readonly truncateLimit = 5;
    readonly ellipsesIndex = 1;
    breadcrumbsInDropdown: DropdownItem[];
    isDropdownOpen: boolean;
    onSelected(item: BreadcrumbItem): void;
    openDropdown(): void;
    closeDropdown(): void;
    selectDropdownItem(selecteds: DropdownItem[]): void;
    ngOnChanges(): void;
    private formatDropdownItems;
}
