export declare class IonModalModule {
}
