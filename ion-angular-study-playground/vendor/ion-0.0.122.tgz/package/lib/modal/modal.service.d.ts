import { ApplicationRef, ComponentFactoryResolver, Injector, Type } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { SafeAny } from './../utils/safe-any';
import { IonModalConfiguration, IonModalResponse, ModalControl } from './models/modal.interface';
export declare class IonModalService {
    private document;
    private componentFactoryResolver;
    private appRef;
    private injector;
    readonly ionOnHeaderButtonAction: Subject<any>;
    modalsControls: ModalControl[];
    private currentModalControl;
    constructor(document: SafeAny, componentFactoryResolver: ComponentFactoryResolver, appRef: ApplicationRef, injector: Injector);
    open(component: Type<unknown>, configuration?: IonModalConfiguration): Observable<IonModalResponse | unknown>;
    emitValue(valueToEmit: IonModalResponse | unknown): void;
    emitValueAndCloseModal(valueToEmit: IonModalResponse | unknown): void;
    emitHeaderAction(valueToEmit: IonModalResponse | unknown): void;
    closeModal(id?: string): void;
    reconfigModal(configuration: IonModalConfiguration): void;
    findModalControlById(id: string): ModalControl | undefined;
    private destroyModalControl;
}
