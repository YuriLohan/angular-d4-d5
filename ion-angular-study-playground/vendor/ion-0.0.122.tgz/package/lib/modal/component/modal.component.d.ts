import { AfterViewInit, ComponentFactoryResolver, ElementRef, EventEmitter, OnInit, Type, ViewContainerRef } from '@angular/core';
import { IonModalConfiguration, IonModalResponse } from '../models/modal.interface';
export declare class IonModalComponent implements OnInit, AfterViewInit {
    private resolver;
    modalBody: ViewContainerRef;
    dialogElement: ElementRef<HTMLDialogElement>;
    componentToBody: Type<unknown>;
    configuration: IonModalConfiguration;
    ionOnHeaderButtonAction: EventEmitter<IonModalResponse>;
    ionOnClose: EventEmitter<IonModalResponse>;
    DEFAULT_WIDTH: number;
    private componentFactory;
    private _defaultModal;
    constructor(resolver: ComponentFactoryResolver);
    closeOnEscapeKeyDown(): void;
    setConfig(config: IonModalConfiguration): void;
    setDefaultConfig(): void;
    getChildComponentPropertiesValue(): IonModalResponse;
    closeModal(valueToEmit?: IonModalResponse | undefined): void;
    setContentInstanceParams<T>(instance: T, params: Partial<T> | undefined): void;
    emitHeaderButtonAction(valueToEmit: IonModalResponse | undefined): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
}
