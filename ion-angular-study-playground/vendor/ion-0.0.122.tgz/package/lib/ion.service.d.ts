export declare class IonService {
}
