export declare class IonCheckboxModule {
}
