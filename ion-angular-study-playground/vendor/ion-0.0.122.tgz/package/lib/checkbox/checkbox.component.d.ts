import { ElementRef, EventEmitter, OnChanges, OnInit, SimpleChanges, SimpleChange } from '@angular/core';
import { CheckBoxStates } from '../core/types/checkbox';
export declare class IonCheckboxComponent implements OnInit, OnChanges {
    label?: string;
    value: string;
    state: CheckBoxStates;
    disabled: boolean;
    ionClick: EventEmitter<{}>;
    checkBox: ElementRef;
    private actions;
    setState(options?: {
        emitEvent: boolean;
    }): void;
    changeState(): void;
    clearIndeterminate(): void;
    setEnabled(options: {
        emitEvent: boolean;
    }): void;
    setIndeterminate(options: {
        emitEvent: boolean;
    }): void;
    setChecked(options: {
        emitEvent: boolean;
    }): void;
    emitEvent(): void;
    stateInputChanged(state: SimpleChange): boolean;
    disabledInputChanged(disabled: SimpleChange): boolean;
    setDisabled(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
}
