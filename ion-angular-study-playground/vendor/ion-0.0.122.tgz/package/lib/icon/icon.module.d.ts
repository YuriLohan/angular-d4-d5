export declare class IonIconModule {
}
