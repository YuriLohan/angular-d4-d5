export declare const iconsPaths: Record<string, string>;
