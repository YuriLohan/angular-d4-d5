import { ElementRef, OnChanges, Renderer2 } from '@angular/core';
import { ContainerStyle, Highlight, IconType } from '../core/types/icon';
export declare class IonIconComponent implements OnChanges {
    private renderer;
    type: IconType;
    size: number;
    color: string;
    highlight: Highlight;
    svgElement: ElementRef;
    outerContainerStyle: ContainerStyle;
    innerContainerStyle: ContainerStyle;
    constructor(renderer: Renderer2);
    setOuterContainerStyle(): void;
    setInnerContainerStyle(): void;
    ngOnChanges(): void;
    private isHex;
    private getCircleProportion;
}
