import { ConfigTable } from '../../lib/table/utilsTable';
import { ConfigSmartTable, OrderTableEvent, PageEvent, SmartTableEvent } from '../../public-api';
import { BnService, IPayload } from '../api/http.interfaces';
export interface SmartPayload {
    offset?: number;
    total?: boolean;
    limit?: number;
    order?: string;
    sort?: string;
}
export interface IBnTable<DataType> {
    service: BnService<DataType>;
    tableConfig: Pick<ConfigTable<DataType>, 'columns' | 'actions'>;
    formatData?: (data: DataType[]) => DataType[];
}
export default class BnTable<DataType> {
    configTable: ConfigSmartTable<DataType>;
    payload: IPayload;
    private service;
    private formatData;
    private firstLoad;
    constructor(config: IBnTable<DataType>);
    filter<T = DataType>(filter: T): void;
    smartData(): void;
    events(event: SmartTableEvent): void;
    handlePageChange(changePage: PageEvent): void;
    handleSort(order: OrderTableEvent): void;
    private resetTablePagination;
    private onInit;
}
