import { PipeStrategy } from './pipe-strategy';
export declare class CurrencyPipeStrategy implements PipeStrategy {
    transform(value: number): string;
}
