import { PipeStrategy } from './pipe-strategy';
export declare class ReplaceEmptyPipeStrategy implements PipeStrategy {
    transform(value: string | number, replaceValue: string): string;
}
