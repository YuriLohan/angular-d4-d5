import { PipeStrategy } from './pipe-strategy';
export declare class DatePipeStrategy implements PipeStrategy {
    transform(value: string, format?: string): string;
}
