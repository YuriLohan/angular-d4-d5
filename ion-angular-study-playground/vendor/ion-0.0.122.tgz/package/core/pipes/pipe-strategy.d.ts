export interface PipeStrategy {
    transform(value: string | number, format?: string): string;
}
export declare class PipeApplicator {
    private strategy;
    constructor(strategy: PipeStrategy);
    apply(value: string | number, format?: string): string;
}
