import { SafeAny } from '../../lib/utils/safe-any';
export declare function clearObject<T = SafeAny>(value: SafeAny): T;
